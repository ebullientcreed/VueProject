export function isPropTrue(v) {
  return v || v === ''
}
